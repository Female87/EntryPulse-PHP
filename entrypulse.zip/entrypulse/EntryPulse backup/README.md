# EntryPulse

## Run with XAMPP

1. Start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Put this project folder under `C:\xampp\htdocs\EntryPulse` (or configure an Apache alias to this folder).
3. Open `http://localhost/EntryPulse/` in your browser. Do not open `index.html` directly from File Explorer; PHP requests need to go through a web server.
4. The first API request creates the `entrypulse_db` database and its API tables automatically. The default connection uses MySQL at `127.0.0.1`, user `root`, and a blank password, which matches a standard XAMPP install.
5. Create an account from the login screen. Existing sample rows in the older SQL dump use placeholder password hashes and are not usable for login.

The API is in `php api/`. `config.php` contains the connection defaults; update them there if your MySQL host, database, username, or password differs. The API uses PHP sessions and PDO MySQL, so make sure `pdo_mysql` is enabled in the XAMPP PHP configuration.

## Connected flows

- Account registration and login use MySQL password hashes and PHP sessions.
- Seat holds are stored for ten minutes and checked transactionally to prevent two accounts from buying the same seat.
- Checkout marks the held seat sold and creates a persistent order and ticket serial in one database transaction.
- Purchase history is loaded from MySQL after login.

GCash, Maya, and card screens remain simulated; this project does not process or store real payment credentials. Social sign-in, password recovery, queue state, and refunds are also still demo-only.